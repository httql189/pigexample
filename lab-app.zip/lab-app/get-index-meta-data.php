<?php

  echo "<table class='table table-bordered'>";
  echo "<tr><th>Meta-Data</th><th>Value</th></tr>";

  #The URL root is the AWS meta data service URL where metadata
  # requests regarding the running instance can be made

  # Get the instance ID from meta-data and print to the screen
  echo "<tr><td>Họ tên</td><td><i>Huỳnh Thảo Tất</i></td><tr>";

  # Availability Zone
  echo "<tr><td>MSSV</td><td><i>17133058</i></td><tr>";

  echo "</table>";

?>
